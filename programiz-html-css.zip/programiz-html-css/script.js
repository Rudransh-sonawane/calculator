const display = document.getElementById("display");
let currentValue = "0";
let previousValue = null;
let operator = null;
let shouldReset = false;

function updateDisplay() {
  display.textContent = currentValue;
}

function inputNumber(num) {
  if (currentValue === "0" || shouldReset) {
    currentValue = num;
    shouldReset = false;
  } else {
    currentValue += num;
  }
  updateDisplay();
}

function inputDecimal() {
  if (!currentValue.includes(".")) {
    currentValue += ".";
    updateDisplay();
  }
}

function clearAll() {
  currentValue = "0";
  previousValue = null;
  operator = null;
  updateDisplay();
}

function chooseOperator(op) {
  if (operator !== null) calculate();
  previousValue = currentValue;
  operator = op;
  shouldReset = true;
}

function calculate() {
  if (operator === null || shouldReset) return;

  let result;
  const prev = parseFloat(previousValue);
  const current = parseFloat(currentValue);

  switch (operator) {
    case "+": result = prev + current; break;
    case "-": result = prev - current; break;
    case "*": result = prev * current; break;
    case "/": result = current === 0 ? "Error" : prev / current; break;
  }

  currentValue = result.toString();
  operator = null;
  updateDisplay();
}

function toggleSign() {
  currentValue = (parseFloat(currentValue) * -1).toString();
  updateDisplay();
}

function percent() {
  currentValue = (parseFloat(currentValue) / 100).toString();
  updateDisplay();
}

/* Button Events */
document.querySelectorAll("[data-number]").forEach(btn =>
  btn.addEventListener("click", () => inputNumber(btn.textContent))
);

document.querySelector("[data-decimal]").addEventListener("click", inputDecimal);

document.querySelectorAll("[data-operator]").forEach(btn =>
  btn.addEventListener("click", () => chooseOperator(btn.dataset.operator))
);

document.querySelector("[data-action='clear']").addEventListener("click", clearAll);
document.querySelector("[data-action='equals']").addEventListener("click", calculate);
document.querySelector("[data-action='sign']").addEventListener("click", toggleSign);
document.querySelector("[data-action='percent']").addEventListener("click", percent);

/* Keyboard Support */
document.addEventListener("keydown", e => {
  if ("0123456789".includes(e.key)) inputNumber(e.key);
  if (e.key === ".") inputDecimal();
  if ("+-*/".includes(e.key)) chooseOperator(e.key);
  if (e.key === "Enter") calculate();
  if (e.key === "Escape") clearAll();
});
